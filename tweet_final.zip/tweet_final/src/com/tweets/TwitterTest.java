package com.tweets;

import twitter4j.IDs;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterTest {
    public static void main(String[] args) {

        try {
            ConfigurationBuilder cb = new ConfigurationBuilder();
            cb.setDebugEnabled(true)
                .setOAuthConsumerKey("i98lWOVZ6DLARCIIQlx5VFOuC")
                .setOAuthConsumerSecret("AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb")
                .setOAuthAccessToken("1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi")
                .setOAuthAccessTokenSecret("NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85");
            TwitterFactory tf = new TwitterFactory(cb.build());
            Twitter twitter = tf.getInstance();
            twitter.verifyCredentials();

            long cursor = -1;
            IDs ids;
            System.out.println("Listing followers's ids.");
            do {
                ids = twitter.getFollowersIDs("SrBachchan", cursor);
                for (long id : ids.getIDs()) {
                    System.out.println(id);
                    User user = twitter.showUser(id);
                    System.out.println(user.getName());
                }
            } while ((cursor = ids.getNextCursor()) != 0);

        } catch (TwitterException e) {
            e.printStackTrace();
        }
    }
}