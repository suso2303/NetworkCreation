package com.tweets;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import org.apache.tomcat.util.net.URL;

import twitter4j.IDs;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;

public class Following {
    String tname1;
    public ArrayList<String> br = new ArrayList();
    public ArrayList<String> brpic = new ArrayList();

    public void setTname1(String tname1) {
        this.tname1 = tname1;
    }

    public ArrayList getFollowing() throws IOException, TwitterException {
        this.getDetailsFollowing();
        return this.br;
    }
    
    public ArrayList getFollowingPic() throws IOException, TwitterException {
    	//this.getDetails();
    	return this.brpic;
    }

    public void getDetailsFollowing() throws IOException, TwitterException {
        String twittername = this.tname1;
        System.out.println(twittername);
        String consumerKey = "i98lWOVZ6DLARCIIQlx5VFOuC";
        String consumerSecret = "AUUpp6zwJf2DvVo0vk6w1BMrpFPGH7YY22YA4kNq5DQ4Hyrtcb";
        String twitterToken = "1493129694-lDWmDcfz1CGmTbs79hbGHykxTgfqOYlXBGofMfi";
        String twitterSecret = "NbIUCMsZ5WDEwQFHhUq6AvM10qimq2k9NEy46I35fos85";
        TwitterFactory factory = new TwitterFactory();
        Twitter twitter = factory.getInstance();
        twitter.setOAuthConsumer(consumerKey, consumerSecret);
        AccessToken accessToken = new AccessToken(twitterToken, twitterSecret);
        twitter.setOAuthAccessToken(accessToken);
        String twitterScreenName = twitter.getScreenName();
        
        IDs followerIDs = twitter.getFriendsIDs(twitterScreenName, -1);
        long[] ids = followerIDs.getIDs();
        String usr = twittername;
        try {
            long[] fofIDs;
            User user = twitter.showUser(usr);
            
            String userScreenName = user.getScreenName();
            IDs followingIDsOfFollowings = twitter.getFriendsIDs(user.getScreenName(), -1);
            long[] arrl = fofIDs = followingIDsOfFollowings.getIDs();
            int n = arrl.length;
            int n2 = 0;
            while (n2 < n) {
                long subId = arrl[n2];
                User user1 = twitter.showUser(subId);
                if(user1.getStatusesCount() > 200 && user1.getStatusesCount() < 500 ){
                	this.br.add(user1.getScreenName());
                    this.brpic.add(user1.getMiniProfileImageURL());
                }
                ++n2;
            }
        }
        catch (TwitterException e1) {
            e1.printStackTrace();
        }
    }
}